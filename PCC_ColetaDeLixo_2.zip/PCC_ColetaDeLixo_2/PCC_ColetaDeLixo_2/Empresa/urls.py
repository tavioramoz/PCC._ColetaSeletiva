from django.urls import path
from django.contrib.auth import views as auth_views
from . import views

app_name = 'Empresa'

urlpatterns = [
    path("", views.index, name="index"),
    path("adicionar_empresa/", views.adicionar_empresa, name="adicionar_empresa"),
    path('editar_empresa/<int:empresa_id>/', views.editar_empresa, name='editar_empresa'),
    path('deletar_empresa/<int:empresa_id>/', views.deletar_empresa, name='deletar_empresa'),
    path('login/', auth_views.LoginView.as_view(template_name='login.html'), name='login'),
    path('consultar_empresas/', views.consultar_empresas, name='consultar_empresas'),
]
