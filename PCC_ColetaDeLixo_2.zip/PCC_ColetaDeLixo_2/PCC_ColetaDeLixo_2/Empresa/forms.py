from django import forms  # Importa o módulo forms do pacote django para criar formulários
from django.contrib.auth.forms import UserCreationForm, UserChangeForm  # Importa formulários de autenticação de usuário do Django
from django.contrib.auth.models import User  # Importa o modelo User do Django
from Empresa.models import Empresa  # Importa o modelo Empresa do aplicativo Empresa
from usuario.models import CustomUser  # Importe o modelo CustomUser

class EmpresaForm(UserCreationForm):
    cnpj = forms.CharField(max_length=18)
    endereco = forms.CharField(widget=forms.Textarea)

    class Meta:
        model = CustomUser  # Atualize o modelo para usar o CustomUser em vez do User
        fields = ['username', 'first_name', 'last_name', 'cnpj', 'endereco', 'email', 'password1', 'password2']

class UserEditForm(UserChangeForm):  # Define uma classe de formulário para editar informações do modelo User
    class Meta:  # Define a classe Meta para configurar metadados do formulário
        model = User  # Define o modelo associado ao formulário como User
        fields = ['username', 'first_name', 'last_name', 'email']  # Define os campos que serão exibidos no formulário

class EmpresaEditForm(forms.ModelForm):  # Define uma classe de formulário model para o modelo Empresa
    class Meta:  # Define a classe Meta para configurar metadados do formulário
        model = Empresa  # Define o modelo associado ao formulário como Empresa
        fields = ['cnpj', 'endereco']  # Define os campos que serão exibidos no formulário
