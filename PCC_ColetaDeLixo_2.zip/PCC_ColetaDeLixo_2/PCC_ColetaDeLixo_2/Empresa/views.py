from django.shortcuts import render, redirect, get_object_or_404, reverse
from django.contrib.auth.decorators import user_passes_test
from Empresa.forms import UserEditForm, EmpresaEditForm, EmpresaForm
from Empresa.models import Empresa
from django.contrib.auth import views as auth_views
from django.http import HttpResponseRedirect
from usuario.models import CustomUser

def index(request):
    empresas = Empresa.objects.all()
    print("Debug: Empresas ->", empresas)  # Linha de debug no console
    context = {
        'title': "Painel Informacional",
        'empresas': empresas,
    }
    return render(request, "index.html", context)

from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import user_passes_test
from Empresa.forms import EmpresaForm
from Empresa.models import Empresa
from usuario.models import CustomUser  # Importe o modelo CustomUser se ainda não estiver importado

@user_passes_test(lambda u: u.is_staff, login_url='/')
def adicionar_empresa(request):
    if not request.user.is_superuser:
        return redirect('/')
    
    if request.method == 'POST':
        form = EmpresaForm(request.POST)
        if form.is_valid():
            # Salve o formulário, obtendo o usuário criado
            user = form.save()
            # Crie uma instância de Empresa, associando-a ao usuário
            empresa = Empresa.objects.create(
                empresa=user,  # Substitua 'user.usuario_ptr' por 'user' se 'empresa' for uma chave estrangeira para o usuário
                cnpj=form.cleaned_data['cnpj'],
                endereco=form.cleaned_data['endereco']
            )
            return redirect('/')
    else:
        form = EmpresaForm()
    
    context = {
        'title': "Adicionar Empresa",
        'form': form,
    }
    return render(request, "adicionar_empresa.html", context)


@user_passes_test(lambda u: u.is_staff, login_url='/')
def editar_empresa(request, empresa_id):
    empresa = get_object_or_404(Empresa, id=empresa_id)
    user_form = UserEditForm(instance=empresa.empresa)
    empresa_form = EmpresaEditForm(instance=empresa)

    if request.method == 'POST':
        user_form = UserEditForm(request.POST, instance=empresa.empresa)
        empresa_form = EmpresaEditForm(request.POST, instance=empresa)
        if user_form.is_valid() and empresa_form.is_valid():
            user_form.save()
            empresa_form.save()
            return redirect('/')
    
    context = {
        'title': "Editar Empresa",
        'user_form': user_form,
        'empresa_form': empresa_form,
    }
    return render(request, "editar_empresa.html", context)

def deletar_empresa(request, empresa_id):
    empresa = get_object_or_404(Empresa, pk=empresa_id)
    user = empresa.empresa
    user.delete()
    empresa.delete()
    return redirect('Empresa:index')

def login(request):
    return auth_views.LoginView.as_view(template_name='login.html')(request)

def consultar_empresas(request):
    empresas = Empresa.objects.all()
    context = {
        'title': "Consultar Empresas",
        'empresas': empresas,
    }
    return render(request, "consultar_empresas.html", context)
