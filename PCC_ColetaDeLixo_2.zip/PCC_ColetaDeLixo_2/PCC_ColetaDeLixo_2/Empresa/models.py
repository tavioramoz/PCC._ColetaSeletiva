from django.conf import settings
from django.db import models

class Empresa(models.Model):
    empresa = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    cnpj = models.CharField(max_length=18, null=True, blank=True)
    endereco = models.TextField(null=True, blank=True)

    def __str__(self):
        return self.empresa.username
