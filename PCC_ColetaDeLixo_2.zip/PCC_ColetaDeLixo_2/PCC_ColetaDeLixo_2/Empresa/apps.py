from django.apps import AppConfig  # Importa a classe AppConfig do pacote django.apps para configurar a aplicação Django

class EmpresaConfig(AppConfig):  # Define uma classe chamada EmpresaConfig que herda de AppConfig
    default_auto_field = 'django.db.models.BigAutoField'  # Define o tipo de campo automático padrão para modelos deste aplicativo
    name = 'Empresa'  # Define o nome do aplicativo como "Empresa"
