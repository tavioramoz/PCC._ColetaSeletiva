from django.contrib import admin  # Importa o módulo admin do pacote django.contrib para registrar modelos no painel de administração
from Empresa import models  # Importa o módulo models do aplicativo Empresa para acessar o modelo Empresa

@admin.register(models.Empresa)  # Registra o modelo Empresa no painel de administração
class Empresa(admin.ModelAdmin):  # Define uma classe para configurar a exibição do modelo Empresa no painel de administração
    list_display = 'empresa_id', 'endereco', 'cnpj', 'id',  # Define os campos a serem exibidos na lista de registros do modelo no painel de administração
