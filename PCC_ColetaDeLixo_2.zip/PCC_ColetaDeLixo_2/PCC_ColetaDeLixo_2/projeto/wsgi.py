import os  # Importa o módulo os para acesso ao Empresa operacional

from django.core.wsgi import get_wsgi_application  # Importa a função get_wsgi_application do pacote django.core.wsgi para configurar a aplicação WSGI

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'projeto.settings')  # Define a variável de ambiente DJANGO_SETTINGS_MODULE para 'projeto.settings'

application = get_wsgi_application()  # Obtém a aplicação WSGI configurada para o projeto Django e atribui à variável application
