import os  # Importa o módulo os para acesso ao Empresa operacional

from django.core.asgi import get_asgi_application  # Importa a função get_asgi_application do pacote django.core.asgi

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'projeto.settings')  # Define a variável de ambiente DJANGO_SETTINGS_MODULE para 'projeto.settings'

application = get_asgi_application()  # Obtém a aplicação ASGI configurada para o projeto Django e atribui à variável application
