from django.contrib import admin  # Importa o módulo admin do pacote django.contrib para acesso à interface de administração do Django
from django.urls import path, include  # Importa as funções path e include do pacote django.urls para definir padrões de URL

urlpatterns = [  # Define uma lista chamada urlpatterns que contém os padrões de URL para o aplicativo
    path('admin/', admin.site.urls),  # Define um padrão de URL para acessar a interface de administração do Django
    path('usuario/', include('usuario.urls')),  # Define um padrão de URL para incluir e rotear URLs do aplicativo 'usuario'
    path('', include('Empresa.urls')),  # Define um padrão de URL para incluir e rotear URLs do aplicativo 'Empresa' na raiz do site
    path('avaliacao/', include('avaliacao.urls')),  # Define um padrão de URL para incluir e rotear URLs do aplicativo 'avaliacao'
]
