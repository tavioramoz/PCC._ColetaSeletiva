from django import forms
from .models import CustomUser

class RegistrationForm(forms.ModelForm):
    email = forms.EmailField(help_text='')  # Remove a mensagem de ajuda para o campo de e-mail

    class Meta:
        model = Usuario
        fields = ['...', 'email',  'cpf', 'address', 'phone']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field_name in self.fields:
            self.fields[field_name].help_text = ''  # Remove a mensagem de ajuda de cada campo

    def save(self, commit=True):
        user = super().save(commit=False)
        user.email = self.cleaned_data['email']
        if commit:
            user.save()
        return user
