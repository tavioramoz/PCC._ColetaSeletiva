from django.db import models
from django.contrib.auth.models import AbstractUser

class Usuario(models.Model):
    cpf = models.CharField(max_length=14, verbose_name="CPF", default='')
    endereceo = models.CharField(max_length=100, verbose_name="Endereço", default='')
    telefone = models.CharField(max_length=15, verbose_name="Telefone", default='')
    senha
    email
    endereco
    prenome
    sobrenome

    def __str__(self):
        return self.username


class Admin(Usuario):

    cidade
    nomerresponsavel
