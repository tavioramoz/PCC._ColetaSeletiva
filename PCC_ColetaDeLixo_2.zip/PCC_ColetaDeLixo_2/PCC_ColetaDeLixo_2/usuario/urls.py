from django.urls import path  # Importa a função path do módulo django.urls
from . import views  # Importa as visualizações do diretório atual

app_name = 'usuario'  # Define um namespace para URLs deste aplicativo

urlpatterns = [  # Lista que contém todas as definições de URL para este aplicativo
    path('login/', views.login_view, name='login'),  # Define a URL para a visualização de login
    path('logout/', views.logout_view, name='logout'),  # Define a URL para a visualização de logout
    path('registro/', views.registro_view, name='registro'),  # Define a URL para a visualização de registro
]
