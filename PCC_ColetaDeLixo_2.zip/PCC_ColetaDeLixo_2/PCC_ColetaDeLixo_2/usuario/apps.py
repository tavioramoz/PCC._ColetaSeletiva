from django.apps import AppConfig  # Importa a classe AppConfig do módulo django.apps

class UsuarioConfig(AppConfig):  # Define uma classe chamada UsuarioConfig que herda de AppConfig
    default_auto_field = 'django.db.models.BigAutoField'  # Define o campo automático padrão para modelos do Django como BigAutoField
    name = 'usuario'  # Define o nome do aplicativo como 'usuario'
